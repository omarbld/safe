export type UserRole = 'donor' | 'charity' | 'volunteer' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  address?: string;
  city?: string;
  profileImage?: string;
  createdAt: Date;
}

export interface Donation {
  id: string;
  donorId: string;
  donorName: string;
  title: string;
  description: string;
  quantity: string;
  expiryDate: Date;
  imageUrl?: string;
  status: 'available' | 'reserved' | 'collected' | 'delivered' | 'expired';
  reservedBy?: string;
  volunteerId?: string;
  volunteerName?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  createdAt: Date;
}

export interface Statistics {
  totalDonations: number;
  totalDelivered: number;
  totalVolunteers: number;
  totalCharities: number;
  totalDonors: number;
  mealsServed: number;
  carbonSaved: number;
}