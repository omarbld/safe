import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';

// Set the document direction to RTL for Arabic language support
document.documentElement.dir = 'rtl';
document.documentElement.lang = 'ar';
document.title = 'SafeFood - منصة مكافحة هدر الطعام في المغرب';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);