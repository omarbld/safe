import { Donation, Notification, Statistics } from '../types';

// Mock donations data
export const mockDonations: Donation[] = [
  {
    id: '1',
    donorId: '1',
    donorName: 'مطعم الأمل',
    title: 'وجبات كسكس',
    description: 'كسكس طازج بالخضروات واللحم من مطعمنا، متبقي من حفل اليوم',
    quantity: '20 وجبة',
    expiryDate: new Date(Date.now() + 24 * 60 * 60 * 1000), // 1 day from now
    imageUrl: 'https://images.pexels.com/photos/5836429/pexels-photo-5836429.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    status: 'available',
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: '2',
    donorId: '1',
    donorName: 'مطعم الأمل',
    title: 'حلويات متنوعة',
    description: 'حلويات مغربية تقليدية متنوعة صالحة للاستهلاك لمدة 3 أيام',
    quantity: '40 قطعة',
    expiryDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
    imageUrl: 'https://images.pexels.com/photos/2067396/pexels-photo-2067396.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    status: 'available',
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 2 * 60 * 60 * 1000)
  },
  {
    id: '3',
    donorId: '5',
    donorName: 'متجر الفواكه الطازجة',
    title: 'فواكه موسمية',
    description: 'تفاح وبرتقال وموز من الحصاد الأخير، ممتازة للاستهلاك',
    quantity: '15 كيلوجرام',
    expiryDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
    imageUrl: 'https://images.pexels.com/photos/1132047/pexels-photo-1132047.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    status: 'reserved',
    reservedBy: '2',
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 12 * 60 * 60 * 1000)
  },
  {
    id: '4',
    donorId: '6',
    donorName: 'مخبز السعادة',
    title: 'خبز طازج',
    description: 'خبز مغربي تقليدي طازج من مخبزنا، صالح لمدة يومين',
    quantity: '30 رغيف',
    expiryDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
    imageUrl: 'https://images.pexels.com/photos/1755785/pexels-photo-1755785.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    status: 'delivered',
    reservedBy: '2',
    volunteerId: '3',
    volunteerName: 'أحمد المتطوع',
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
  },
  {
    id: '5',
    donorId: '1',
    donorName: 'مطعم الأمل',
    title: 'طاجين بالخضار',
    description: 'طاجين مغربي تقليدي بالخضروات الطازجة',
    quantity: '10 وجبات',
    expiryDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // 1 day from now
    imageUrl: 'https://images.pexels.com/photos/6419736/pexels-photo-6419736.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    status: 'collected',
    reservedBy: '2',
    volunteerId: '3',
    volunteerName: 'أحمد المتطوع',
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 6 * 60 * 60 * 1000)
  }
];

// Mock notifications
export const mockNotifications: Notification[] = [
  {
    id: '1',
    userId: '1',
    title: 'طلب جديد',
    message: 'تم طلب تبرعك "وجبات كسكس" من قبل جمعية الخير للجميع',
    type: 'info',
    read: false,
    createdAt: new Date(Date.now() - 30 * 60 * 1000)
  },
  {
    id: '2',
    userId: '2',
    title: 'تأكيد استلام',
    message: 'تم تأكيد استلام تبرع "خبز طازج" بنجاح',
    type: 'success',
    read: true,
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
  },
  {
    id: '3',
    userId: '3',
    title: 'مهمة توصيل جديدة',
    message: 'لديك مهمة توصيل جديدة من مطعم الأمل إلى جمعية الخير للجميع',
    type: 'info',
    read: false,
    createdAt: new Date(Date.now() - 45 * 60 * 1000)
  },
  {
    id: '4',
    userId: '1',
    title: 'تنبيه انتهاء صلاحية',
    message: 'تبرعك "فواكه موسمية" سينتهي خلال 24 ساعة',
    type: 'warning',
    read: false,
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000)
  }
];

// Mock statistics
export const mockStatistics: Statistics = {
  totalDonations: 124,
  totalDelivered: 98,
  totalVolunteers: 35,
  totalCharities: 12,
  totalDonors: 28,
  mealsServed: 1450,
  carbonSaved: 385 // kg of CO2 equivalent
};