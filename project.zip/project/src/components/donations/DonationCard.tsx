import React from 'react';
import { formatDistance } from 'date-fns';
import { Clock, MapPin, Package } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Donation } from '../../types';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import { Card, CardContent, CardFooter } from '../ui/Card';

interface DonationCardProps {
  donation: Donation;
  onReserve?: (id: string) => void;
  showReserve?: boolean;
  showViewDetails?: boolean;
}

const DonationCard: React.FC<DonationCardProps> = ({ 
  donation, 
  onReserve,
  showReserve = true,
  showViewDetails = true
}) => {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'available':
        return <Badge variant="success">متاح</Badge>;
      case 'reserved':
        return <Badge variant="secondary">محجوز</Badge>;
      case 'collected':
        return <Badge variant="primary">تم الاستلام</Badge>;
      case 'delivered':
        return <Badge variant="success">تم التوصيل</Badge>;
      case 'expired':
        return <Badge variant="danger">منتهي الصلاحية</Badge>;
      default:
        return <Badge>غير معروف</Badge>;
    }
  };
  
  const timeLeft = formatDistance(new Date(donation.expiryDate), new Date(), { addSuffix: true });
  const isExpiringSoon = new Date(donation.expiryDate).getTime() - Date.now() < 24 * 60 * 60 * 1000;
  
  return (
    <Card className="h-full transition-all duration-300 hover:shadow-lg">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={donation.imageUrl || 'https://images.pexels.com/photos/6941028/pexels-photo-6941028.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'} 
          alt={donation.title} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
        <div className="absolute top-2 right-2">
          {getStatusBadge(donation.status)}
        </div>
      </div>
      
      <CardContent className="pt-4">
        <h3 className="text-xl font-bold mb-2 text-right">{donation.title}</h3>
        <p className="text-gray-600 mb-4 text-right line-clamp-2">{donation.description}</p>
        
        <div className="space-y-2">
          <div className="flex items-center justify-end text-sm text-gray-600">
            <span>{donation.donorName}</span>
          </div>
          <div className="flex items-center justify-end text-sm text-gray-600">
            <span className="mr-1">{donation.quantity}</span>
            <Package size={16} className="ml-1" />
          </div>
          <div className="flex items-center justify-end text-sm text-gray-600">
            <span className={`mr-1 ${isExpiringSoon ? 'text-red-600 font-medium' : ''}`}>
              {timeLeft}
            </span>
            <Clock size={16} className={`ml-1 ${isExpiringSoon ? 'text-red-600' : ''}`} />
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between border-t pt-4">
        {showViewDetails && (
          <Link to={`/donations/${donation.id}`} className="text-green-700 hover:underline text-sm">
            عرض التفاصيل
          </Link>
        )}
        
        {showReserve && donation.status === 'available' && onReserve && (
          <Button
            variant="primary"
            size="sm"
            onClick={() => onReserve(donation.id)}
          >
            طلب الحصول
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default DonationCard;