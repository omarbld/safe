import React, { useState } from 'react';
import { PlusCircle } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';

interface DonationFormProps {
  onSubmit: (donationData: FormData) => void;
  loading?: boolean;
}

interface FormData {
  title: string;
  description: string;
  quantity: string;
  expiryDate: string;
  image?: File;
}

const DonationForm: React.FC<DonationFormProps> = ({ onSubmit, loading = false }) => {
  const [formData, setFormData] = useState<FormData>({
    title: '',
    description: '',
    quantity: '',
    expiryDate: '',
  });
  
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: '',
      });
    }
  };
  
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    
    if (file) {
      if (file.type.startsWith('image/')) {
        setFormData({
          ...formData,
          image: file,
        });
        
        const reader = new FileReader();
        reader.onloadend = () => {
          setImagePreview(reader.result as string);
        };
        reader.readAsDataURL(file);
        
        // Clear error
        if (errors.image) {
          setErrors({
            ...errors,
            image: '',
          });
        }
      } else {
        setErrors({
          ...errors,
          image: 'الرجاء اختيار ملف صورة صالح',
        });
      }
    }
  };
  
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'عنوان التبرع مطلوب';
    }
    
    if (!formData.description.trim()) {
      newErrors.description = 'وصف التبرع مطلوب';
    }
    
    if (!formData.quantity.trim()) {
      newErrors.quantity = 'الكمية مطلوبة';
    }
    
    if (!formData.expiryDate.trim()) {
      newErrors.expiryDate = 'تاريخ انتهاء الصلاحية مطلوب';
    } else {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const selectedDate = new Date(formData.expiryDate);
      
      if (selectedDate < today) {
        newErrors.expiryDate = 'يجب أن يكون تاريخ انتهاء الصلاحية في المستقبل';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      onSubmit(formData);
    }
  };
  
  // Get today's date in YYYY-MM-DD format for min attribute
  const today = new Date().toISOString().split('T')[0];
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4" dir="rtl">
      <Input
        label="عنوان التبرع *"
        name="title"
        value={formData.title}
        onChange={handleChange}
        placeholder="مثال: وجبات كسكس"
        error={errors.title}
        fullWidth
      />
      
      <div className="mb-4">
        <label className="block text-gray-700 font-medium mb-1 text-right">
          وصف التبرع *
        </label>
        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="تفاصيل عن الطعام، كميته، حالته..."
          rows={4}
          className={`block w-full px-4 py-2 bg-white border rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600 outline-none transition-colors ${
            errors.description ? 'border-red-500' : 'border-gray-300'
          }`}
        ></textarea>
        {errors.description && (
          <p className="mt-1 text-sm text-red-600 text-right">{errors.description}</p>
        )}
      </div>
      
      <Input
        label="الكمية *"
        name="quantity"
        value={formData.quantity}
        onChange={handleChange}
        placeholder="مثال: 20 وجبة، 10 كيلوغرام"
        error={errors.quantity}
        fullWidth
      />
      
      <Input
        label="تاريخ انتهاء الصلاحية *"
        type="date"
        name="expiryDate"
        value={formData.expiryDate}
        onChange={handleChange}
        min={today}
        error={errors.expiryDate}
        fullWidth
      />
      
      <div className="mb-4">
        <label className="block text-gray-700 font-medium mb-1 text-right">
          صورة الطعام (اختياري)
        </label>
        <div className="flex items-center justify-end space-x-4 space-x-reverse">
          <div className="relative">
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              aria-label="اختيار صورة"
            />
            <Button
              type="button"
              variant="outline"
              icon={<PlusCircle size={16} />}
            >
              اختيار صورة
            </Button>
          </div>
          {imagePreview && (
            <div className="h-16 w-16 relative rounded-md overflow-hidden border border-gray-300">
              <img
                src={imagePreview}
                alt="معاينة الصورة"
                className="h-full w-full object-cover"
              />
            </div>
          )}
        </div>
        {errors.image && (
          <p className="mt-1 text-sm text-red-600 text-right">{errors.image}</p>
        )}
      </div>
      
      <div className="flex justify-end">
        <Button
          type="submit"
          variant="primary"
          loading={loading}
        >
          نشر التبرع
        </Button>
      </div>
    </form>
  );
};

export default DonationForm;