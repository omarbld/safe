import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Select from '../ui/Select';

const LoginForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('donor');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const navigate = useNavigate();
  const { login } = useAuth();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    try {
      await login(email, password, role);
      navigate('/dashboard');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'حدث خطأ أثناء تسجيل الدخول');
    } finally {
      setLoading(false);
    }
  };
  
  const roleOptions = [
    { value: 'donor', label: 'متبرع (مطعم / متجر)' },
    { value: 'charity', label: 'جمعية خيرية' },
    { value: 'volunteer', label: 'متطوع' },
    { value: 'admin', label: 'مدير النظام' },
  ];
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6" dir="rtl">
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-right">
          {error}
        </div>
      )}
      
      <Select
        label="نوع الحساب"
        options={roleOptions}
        value={role}
        onChange={setRole}
        fullWidth
      />
      
      <Input
        label="البريد الإلكتروني"
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="أدخل بريدك الإلكتروني"
        required
        fullWidth
      />
      
      <Input
        label="كلمة المرور"
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="أدخل كلمة المرور"
        required
        fullWidth
      />
      
      <div className="text-left">
        <Button type="submit" loading={loading}>
          تسجيل الدخول
        </Button>
      </div>
    </form>
  );
};

export default LoginForm;