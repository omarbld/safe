import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Select from '../ui/Select';

const RegisterForm: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'donor' as UserRole,
    phone: '',
    address: '',
    city: '',
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [generalError, setGeneralError] = useState('');
  
  const navigate = useNavigate();
  const { register } = useAuth();
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: '',
      });
    }
  };
  
  const handleRoleChange = (value: string) => {
    setFormData({
      ...formData,
      role: value as UserRole,
    });
  };
  
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'الاسم مطلوب';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'البريد الإلكتروني مطلوب';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'البريد الإلكتروني غير صالح';
    }
    
    if (!formData.password) {
      newErrors.password = 'كلمة المرور مطلوبة';
    } else if (formData.password.length < 6) {
      newErrors.password = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
    }
    
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'كلمات المرور غير متطابقة';
    }
    
    if (formData.role !== 'admin' && !formData.phone) {
      newErrors.phone = 'رقم الهاتف مطلوب';
    }
    
    if ((formData.role === 'donor' || formData.role === 'charity') && !formData.address) {
      newErrors.address = 'العنوان مطلوب';
    }
    
    if (!formData.city && formData.role !== 'admin') {
      newErrors.city = 'المدينة مطلوبة';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGeneralError('');
    
    if (!validateForm()) {
      return;
    }
    
    setLoading(true);
    
    try {
      await register(formData.email, formData.password, formData.name, formData.role);
      navigate('/dashboard');
    } catch (err) {
      setGeneralError(err instanceof Error ? err.message : 'حدث خطأ أثناء إنشاء الحساب');
    } finally {
      setLoading(false);
    }
  };
  
  const roleOptions = [
    { value: 'donor', label: 'متبرع (مطعم / متجر)' },
    { value: 'charity', label: 'جمعية خيرية' },
    { value: 'volunteer', label: 'متطوع' },
  ];
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4" dir="rtl">
      {generalError && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-right">
          {generalError}
        </div>
      )}
      
      <Select
        label="نوع الحساب *"
        options={roleOptions}
        value={formData.role}
        onChange={handleRoleChange}
        fullWidth
      />
      
      <Input
        label="الاسم *"
        name="name"
        value={formData.name}
        onChange={handleChange}
        placeholder={formData.role === 'donor' ? "اسم المطعم / المتجر" : formData.role === 'charity' ? "اسم الجمعية" : "الاسم الكامل"}
        error={errors.name}
        fullWidth
      />
      
      <Input
        label="البريد الإلكتروني *"
        type="email"
        name="email"
        value={formData.email}
        onChange={handleChange}
        placeholder="أدخل بريدك الإلكتروني"
        error={errors.email}
        fullWidth
      />
      
      <Input
        label="كلمة المرور *"
        type="password"
        name="password"
        value={formData.password}
        onChange={handleChange}
        placeholder="كلمة المرور"
        error={errors.password}
        fullWidth
      />
      
      <Input
        label="تأكيد كلمة المرور *"
        type="password"
        name="confirmPassword"
        value={formData.confirmPassword}
        onChange={handleChange}
        placeholder="أعد إدخال كلمة المرور"
        error={errors.confirmPassword}
        fullWidth
      />
      
      <Input
        label="رقم الهاتف *"
        name="phone"
        value={formData.phone}
        onChange={handleChange}
        placeholder="+212..."
        error={errors.phone}
        fullWidth
      />
      
      {(formData.role === 'donor' || formData.role === 'charity') && (
        <Input
          label="العنوان *"
          name="address"
          value={formData.address}
          onChange={handleChange}
          placeholder="العنوان التفصيلي"
          error={errors.address}
          fullWidth
        />
      )}
      
      <Input
        label="المدينة *"
        name="city"
        value={formData.city}
        onChange={handleChange}
        placeholder="المدينة"
        error={errors.city}
        fullWidth
      />
      
      <div className="flex justify-end pt-2">
        <Button
          type="submit"
          loading={loading}
        >
          إنشاء حساب
        </Button>
      </div>
    </form>
  );
};

export default RegisterForm;