import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  fullWidth?: boolean;
  helperText?: string;
}

const Input: React.FC<InputProps> = ({
  label,
  error,
  fullWidth = false,
  helperText,
  className = '',
  ...props
}) => {
  const inputClasses = `block px-4 py-2 bg-white border rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600 outline-none transition-colors ${
    error ? 'border-red-500' : 'border-gray-300'
  } ${className}`;

  const containerClasses = `mb-4 ${fullWidth ? 'w-full' : ''}`;

  return (
    <div className={containerClasses}>
      {label && (
        <label className="block text-gray-700 font-medium mb-1 text-right">
          {label}
        </label>
      )}
      <input className={inputClasses} {...props} />
      {error && <p className="mt-1 text-sm text-red-600 text-right">{error}</p>}
      {helperText && !error && <p className="mt-1 text-sm text-gray-500 text-right">{helperText}</p>}
    </div>
  );
};

export default Input;