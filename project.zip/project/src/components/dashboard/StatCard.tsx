import React from 'react';

interface StatCardProps {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  suffix?: string;
}

const StatCard: React.FC<StatCardProps> = ({ 
  title, 
  value, 
  icon, 
  trend,
  suffix
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 transition-all duration-300 hover:shadow-lg">
      <div className="flex justify-between items-start">
        <div className="flex-grow">
          <h3 className="text-gray-500 font-medium text-sm mb-1 text-right">{title}</h3>
          <div className="flex items-center justify-end">
            <p className="text-2xl font-bold text-gray-900">
              {value}
              {suffix && <span className="text-sm ml-1">{suffix}</span>}
            </p>
          </div>
          
          {trend && (
            <p className={`text-sm mt-2 ${trend.isPositive ? 'text-green-600' : 'text-red-600'} text-right`}>
              {trend.isPositive ? '+' : ''}{trend.value}% منذ الشهر الماضي
            </p>
          )}
        </div>
        
        <div className="p-3 rounded-full bg-green-100 text-green-700">
          {icon}
        </div>
      </div>
    </div>
  );
};

export default StatCard;