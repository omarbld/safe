import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Mail, Phone } from 'lucide-react';

const Footer: React.FC = () => {
  const year = new Date().getFullYear();
  
  return (
    <footer className="bg-green-800 text-white" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">حول SafeFood</h3>
            <p className="text-gray-200 mb-4">
              منصة رقمية مغربية تهدف إلى مكافحة هدر الطعام من خلال ربط أصحاب فائض الطعام بالمحتاجين والجمعيات الخيرية.
            </p>
            <div className="flex space-x-4 space-x-reverse">
              <a href="#" className="text-white hover:text-amber-300 transition-colors">
                <Facebook size={20} />
                <span className="sr-only">فيسبوك</span>
              </a>
              <a href="#" className="text-white hover:text-amber-300 transition-colors">
                <Twitter size={20} />
                <span className="sr-only">تويتر</span>
              </a>
              <a href="#" className="text-white hover:text-amber-300 transition-colors">
                <Instagram size={20} />
                <span className="sr-only">انستغرام</span>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">روابط مهمة</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-200 hover:text-amber-300 transition-colors">الصفحة الرئيسية</Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-200 hover:text-amber-300 transition-colors">من نحن</Link>
              </li>
              <li>
                <Link to="/vision" className="text-gray-200 hover:text-amber-300 transition-colors">رؤية 2030</Link>
              </li>
              <li>
                <Link to="/statistics" className="text-gray-200 hover:text-amber-300 transition-colors">الإحصائيات</Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-200 hover:text-amber-300 transition-colors">اتصل بنا</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">اتصل بنا</h3>
            <address className="not-italic">
              <div className="flex items-center space-x-2 space-x-reverse mb-2">
                <Mail size={18} />
                <a href="mailto:info@safefood.ma" className="text-gray-200 hover:text-amber-300 transition-colors">info@safefood.ma</a>
              </div>
              <div className="flex items-center space-x-2 space-x-reverse mb-2">
                <Phone size={18} />
                <a href="tel:+212522000000" className="text-gray-200 hover:text-amber-300 transition-colors">+212 522 000 000</a>
              </div>
              <p className="text-gray-200">
                شارع محمد الخامس، الرباط، المغرب
              </p>
            </address>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-green-700">
          <p className="text-center text-gray-300">
            &copy; {year} منصة SafeFood لمكافحة هدر الطعام في المغرب. جميع الحقوق محفوظة.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;