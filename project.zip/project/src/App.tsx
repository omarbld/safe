import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';

// Layout Components
import Navbar from './components/common/Navbar';
import Footer from './components/common/Footer';

// Pages
import Home from './pages/Home';
import About from './pages/About';
import Vision2030 from './pages/Vision2030';
import Statistics from './pages/Statistics';
import Contact from './pages/Contact';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import DonationsList from './pages/donations/DonationsList';
import DonationDetails from './pages/donations/DonationDetails';

// Dashboard Pages
import DonorDashboard from './pages/dashboard/DonorDashboard';
import CharityDashboard from './pages/dashboard/CharityDashboard';
import VolunteerDashboard from './pages/dashboard/VolunteerDashboard';
import AdminDashboard from './pages/dashboard/AdminDashboard';

// Protected Route Component
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-700"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

// Role-based Route Component
const RoleRoute: React.FC<{ children: React.ReactNode, roles: string[] }> = ({ children, roles }) => {
  const { currentUser, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-700"></div>
      </div>
    );
  }

  if (!currentUser || !roles.includes(currentUser.role)) {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
};

// Dashboard Router - Redirects to the appropriate dashboard based on user role
const DashboardRouter: React.FC = () => {
  const { currentUser } = useAuth();

  switch (currentUser?.role) {
    case 'donor':
      return <DonorDashboard />;
    case 'charity':
      return <CharityDashboard />;
    case 'volunteer':
      return <VolunteerDashboard />;
    case 'admin':
      return <AdminDashboard />;
    default:
      return <Navigate to="/" replace />;
  }
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <Router>
        <div className="flex flex-col min-h-screen">
          <Navbar />
          
          <main className="flex-grow">
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/vision" element={<Vision2030 />} />
              <Route path="/statistics" element={<Statistics />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              
              {/* Semi-protected Routes */}
              <Route 
                path="/donations" 
                element={<DonationsList />} 
              />
              <Route 
                path="/donations/:id" 
                element={<DonationDetails />} 
              />
              
              {/* Protected Routes */}
              <Route 
                path="/dashboard" 
                element={
                  <ProtectedRoute>
                    <DashboardRouter />
                  </ProtectedRoute>
                } 
              />

              {/* Profile Route - Redirects to Dashboard */}
              <Route 
                path="/profile" 
                element={
                  <ProtectedRoute>
                    <Navigate to="/dashboard\" replace />
                  </ProtectedRoute>
                } 
              />
              
              {/* Admin Routes */}
              <Route 
                path="/admin" 
                element={
                  <RoleRoute roles={['admin']}>
                    <AdminDashboard />
                  </RoleRoute>
                } 
              />
              
              {/* Fallback Route */}
              <Route path="*" element={<Navigate to="/\" replace />} />
            </Routes>
          </main>
          
          <Footer />
        </div>
        
        <Toaster position="top-center" toastOptions={{
          duration: 5000,
          style: {
            background: '#fff',
            color: '#333',
            boxShadow: '0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24)',
            borderRadius: '0.5rem',
            fontWeight: 500,
          },
          success: {
            iconTheme: {
              primary: '#2E7D32',
              secondary: '#fff',
            },
          },
          error: {
            iconTheme: {
              primary: '#E53935',
              secondary: '#fff',
            },
          },
        }} />
      </Router>
    </AuthProvider>
  );
};

export default App;