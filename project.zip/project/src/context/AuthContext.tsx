import React, { createContext, useState, useContext, useEffect } from 'react';
import { User, UserRole } from '../types';

// Mock authentication for demonstration purposes
// In a real app, replace this with Firebase auth or similar

interface AuthContextType {
  currentUser: User | null;
  loading: boolean;
  login: (email: string, password: string, role: UserRole) => Promise<void>;
  register: (email: string, password: string, name: string, role: UserRole) => Promise<void>;
  logout: () => Promise<void>;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Sample user data
const MOCK_USERS: Record<string, User> = {
  'donor@example.com': {
    id: '1',
    name: 'مطعم الأمل',
    email: 'donor@example.com',
    role: 'donor',
    phone: '+212612345678',
    address: 'شارع محمد الخامس، الرباط',
    city: 'الرباط',
    createdAt: new Date(),
  },
  'charity@example.com': {
    id: '2',
    name: 'جمعية الخير للجميع',
    email: 'charity@example.com',
    role: 'charity',
    phone: '+212687654321',
    address: 'شارع الحسن الثاني، الدار البيضاء',
    city: 'الدار البيضاء',
    createdAt: new Date(),
  },
  'volunteer@example.com': {
    id: '3',
    name: 'أحمد المتطوع',
    email: 'volunteer@example.com',
    role: 'volunteer',
    phone: '+212654321987',
    city: 'الرباط',
    createdAt: new Date(),
  },
  'admin@example.com': {
    id: '4',
    name: 'مدير النظام',
    email: 'admin@example.com',
    role: 'admin',
    createdAt: new Date(),
  },
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for stored user in localStorage
    const storedUser = localStorage.getItem('safefood_user');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string, role: UserRole): Promise<void> => {
    setLoading(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Check if user exists in our mock data
    const user = MOCK_USERS[email];
    if (user && user.role === role) {
      setCurrentUser(user);
      localStorage.setItem('safefood_user', JSON.stringify(user));
    } else {
      throw new Error('بيانات الدخول غير صحيحة');
    }
    
    setLoading(false);
  };

  const register = async (email: string, password: string, name: string, role: UserRole): Promise<void> => {
    setLoading(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Check if user already exists
    if (MOCK_USERS[email]) {
      throw new Error('البريد الإلكتروني مسجل بالفعل');
    }
    
    // Create new user
    const newUser: User = {
      id: Math.random().toString(36).substring(2, 9),
      name,
      email,
      role,
      createdAt: new Date(),
    };
    
    // In a real app, we'd save this to the database
    // For demo, just update our local mock and set as current
    MOCK_USERS[email] = newUser;
    setCurrentUser(newUser);
    localStorage.setItem('safefood_user', JSON.stringify(newUser));
    
    setLoading(false);
  };

  const logout = async (): Promise<void> => {
    localStorage.removeItem('safefood_user');
    setCurrentUser(null);
  };

  const value = {
    currentUser,
    loading,
    login,
    register,
    logout,
    isAuthenticated: !!currentUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};