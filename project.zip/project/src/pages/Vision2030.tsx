import React from 'react';
import { TrendingUp, Target, Leaf, PieChart, Lightbulb, Award } from 'lucide-react';
import { Card, CardContent } from '../components/ui/Card';

const Vision2030: React.FC = () => {
  return (
    <div dir="rtl">
      {/* Hero Section */}
      <section className="relative bg-green-700 text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.pexels.com/photos/775031/pexels-photo-775031.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
            alt="رؤية 2030"
            className="w-full h-full object-cover opacity-20"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32 relative z-10">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              رؤية <span className="text-amber-400">2030</span>
            </h1>
            <p className="text-xl md:text-2xl mb-4 max-w-3xl mx-auto">
              استراتيجيتنا للقضاء على هدر الطعام في المغرب
            </p>
            <p className="text-lg max-w-3xl mx-auto">
              نسعى إلى خفض هدر الطعام بنسبة 50% بحلول عام 2030 تماشيًا مع أهداف التنمية المستدامة للأمم المتحدة
            </p>
          </div>
        </div>
      </section>

      {/* Vision Overview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">نظرة عامة على الرؤية</h2>
            <p className="text-lg text-gray-600">
              تتماشى رؤيتنا مع الهدف 12.3 من أهداف التنمية المستدامة للأمم المتحدة والذي يدعو إلى خفض نصيب الفرد من النفايات الغذائية العالمية على مستوى البيع بالتجزئة والمستهلكين بمقدار النصف بحلول عام 2030.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <Card className="bg-green-50 border border-green-100 transform transition-transform duration-300 hover:-translate-y-2">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-green-100 text-green-700 rounded-full flex items-center justify-center mb-4">
                  <Target size={24} />
                </div>
                <h3 className="text-xl font-bold mb-3 text-right">هدفنا</h3>
                <p className="text-gray-600 text-right">
                  خفض هدر الطعام في المغرب بنسبة 50% بحلول عام 2030 من خلال حلول مبتكرة تربط بين جميع أطراف سلسلة الإمداد الغذائي.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-amber-50 border border-amber-100 transform transition-transform duration-300 hover:-translate-y-2">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center mb-4">
                  <Leaf size={24} />
                </div>
                <h3 className="text-xl font-bold mb-3 text-right">الاستدامة</h3>
                <p className="text-gray-600 text-right">
                  المساهمة في تقليل البصمة الكربونية وتحقيق الاستدامة البيئية من خلال منع تحلل الطعام في مكبات النفايات.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-blue-50 border border-blue-100 transform transition-transform duration-300 hover:-translate-y-2">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center mb-4">
                  <Users size={24} />
                </div>
                <h3 className="text-xl font-bold mb-3 text-right">التأثير الاجتماعي</h3>
                <p className="text-gray-600 text-right">
                  توفير الطعام للمحتاجين وتعزيز روح التضامن المجتمعي، والمساهمة في تحقيق الأمن الغذائي.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Strategic Pillars */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">الركائز الاستراتيجية</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              استراتيجيتنا مبنية على أربع ركائز أساسية تقودنا نحو تحقيق أهدافنا
            </p>
          </div>

          <div className="space-y-8">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="md:flex">
                <div className="md:flex-shrink-0 bg-green-700 md:w-48 flex items-center justify-center p-6">
                  <div className="text-white">
                    <PieChart size={64} />
                  </div>
                </div>
                <div className="p-8">
                  <div className="flex items-center">
                    <h3 className="text-2xl font-bold text-gray-900">1. قياس وتتبع الهدر</h3>
                  </div>
                  <p className="mt-2 text-lg text-gray-600">
                    تطوير نظام دقيق لقياس كميات الطعام المهدرة في مختلف مراحل سلسلة الإمداد الغذائي، وتوثيق البيانات لقياس التقدم المحرز.
                  </p>
                  <div className="mt-4">
                    <ul className="list-disc list-inside text-gray-600 space-y-2">
                      <li>تطوير مؤشرات أداء رئيسية لتتبع هدر الطعام</li>
                      <li>إنشاء نظام تقارير موحد للمطاعم والمتاجر</li>
                      <li>تحليل البيانات ونشر التقارير الدورية</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="md:flex">
                <div className="md:flex-shrink-0 bg-amber-500 md:w-48 flex items-center justify-center p-6">
                  <div className="text-white">
                    <Lightbulb size={64} />
                  </div>
                </div>
                <div className="p-8">
                  <div className="flex items-center">
                    <h3 className="text-2xl font-bold text-gray-900">2. التوعية والتثقيف</h3>
                  </div>
                  <p className="mt-2 text-lg text-gray-600">
                    نشر الوعي حول أهمية الحد من هدر الطعام وتثقيف المجتمع بطرق حفظ الطعام واستخدام الفائض بشكل فعال.
                  </p>
                  <div className="mt-4">
                    <ul className="list-disc list-inside text-gray-600 space-y-2">
                      <li>حملات توعية في المدارس والجامعات</li>
                      <li>ورش عمل للمطاعم والفنادق حول تقليل الهدر</li>
                      <li>منشورات توعوية على منصات التواصل الاجتماعي</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="md:flex">
                <div className="md:flex-shrink-0 bg-blue-600 md:w-48 flex items-center justify-center p-6">
                  <div className="text-white">
                    <Truck size={64} />
                  </div>
                </div>
                <div className="p-8">
                  <div className="flex items-center">
                    <h3 className="text-2xl font-bold text-gray-900">3. البنية التحتية والتكنولوجيا</h3>
                  </div>
                  <p className="mt-2 text-lg text-gray-600">
                    تطوير البنية التحتية اللازمة لجمع وتوزيع الطعام الفائض، واستخدام التكنولوجيا لتحسين كفاءة العمليات.
                  </p>
                  <div className="mt-4">
                    <ul className="list-disc list-inside text-gray-600 space-y-2">
                      <li>توسيع شبكة النقل والتوزيع في المدن المغربية</li>
                      <li>تطوير تطبيق الهاتف المحمول للوصول لشريحة أكبر</li>
                      <li>استخدام الذكاء الاصطناعي للتنبؤ بالهدر وتوجيه التبرعات</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="md:flex">
                <div className="md:flex-shrink-0 bg-green-800 md:w-48 flex items-center justify-center p-6">
                  <div className="text-white">
                    <Award size={64} />
                  </div>
                </div>
                <div className="p-8">
                  <div className="flex items-center">
                    <h3 className="text-2xl font-bold text-gray-900">4. الشراكات والتعاون</h3>
                  </div>
                  <p className="mt-2 text-lg text-gray-600">
                    بناء شراكات استراتيجية مع الحكومة والقطاع الخاص والجمعيات لتوسيع نطاق عملنا وتأثيرنا.
                  </p>
                  <div className="mt-4">
                    <ul className="list-disc list-inside text-gray-600 space-y-2">
                      <li>التعاون مع وزارة البيئة ووزارة الفلاحة</li>
                      <li>شراكات مع سلاسل المطاعم والفنادق الكبرى</li>
                      <li>التنسيق مع الجمعيات الخيرية في مختلف المدن المغربية</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Roadmap */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">خارطة الطريق</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              خطتنا التنفيذية على مدار السنوات القادمة لتحقيق أهداف 2030
            </p>
          </div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute top-0 bottom-0 right-1/2 w-0.5 bg-green-200 hidden md:block"></div>

            {/* Timeline Items */}
            <div className="space-y-12">
              {/* 2023-2024 */}
              <div className="relative md:grid md:grid-cols-2">
                <div className="md:col-start-1 md:pr-12 md:text-right">
                  <div className="absolute hidden md:block right-1/2 top-5 -mr-3.5 h-7 w-7 rounded-full border-4 border-white bg-green-700"></div>
                  <div className="bg-green-50 p-6 rounded-lg shadow-sm border border-green-100 mb-8 md:mb-0 transform transition-transform duration-300 hover:-translate-y-1">
                    <h3 className="text-xl font-bold text-green-900 mb-2">2023-2024: التأسيس والإطلاق</h3>
                    <ul className="list-disc list-inside text-gray-700 space-y-2">
                      <li>إطلاق منصة SafeFood في 5 مدن رئيسية</li>
                      <li>استقطاب 100 مطعم ومتجر و20 جمعية خيرية</li>
                      <li>تنفيذ حملة توعية على مستوى الرباط والدار البيضاء</li>
                      <li>بناء شبكة من 50 متطوع نشط</li>
                    </ul>
                  </div>
                </div>
                <div className="md:col-start-1"></div>
              </div>

              {/* 2025-2026 */}
              <div className="relative md:grid md:grid-cols-2">
                <div className="md:col-start-2 md:pl-12">
                  <div className="absolute hidden md:block right-1/2 top-5 -mr-3.5 h-7 w-7 rounded-full border-4 border-white bg-amber-500"></div>
                  <div className="bg-amber-50 p-6 rounded-lg shadow-sm border border-amber-100 transform transition-transform duration-300 hover:-translate-y-1">
                    <h3 className="text-xl font-bold text-amber-900 mb-2 text-right">2025-2026: التوسع والنمو</h3>
                    <ul className="list-disc list-inside text-gray-700 space-y-2 text-right">
                      <li>توسيع نطاق العمل ليشمل 12 مدينة مغربية</li>
                      <li>إطلاق تطبيق الهاتف المحمول</li>
                      <li>تنفيذ نظام تصنيف للمتبرعين والمتطوعين</li>
                      <li>خفض هدر الطعام بنسبة 15% في المطاعم المشاركة</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* 2027-2028 */}
              <div className="relative md:grid md:grid-cols-2">
                <div className="md:col-start-1 md:pr-12 md:text-right">
                  <div className="absolute hidden md:block right-1/2 top-5 -mr-3.5 h-7 w-7 rounded-full border-4 border-white bg-blue-600"></div>
                  <div className="bg-blue-50 p-6 rounded-lg shadow-sm border border-blue-100 mb-8 md:mb-0 transform transition-transform duration-300 hover:-translate-y-1">
                    <h3 className="text-xl font-bold text-blue-900 mb-2">2027-2028: التعمق والتأثير</h3>
                    <ul className="list-disc list-inside text-gray-700 space-y-2">
                      <li>تغطية جميع المدن الرئيسية في المغرب</li>
                      <li>تنفيذ حلول ذكية للتنبؤ بالهدر</li>
                      <li>إطلاق برنامج شهادات للمطاعم والمتاجر المسؤولة</li>
                      <li>خفض هدر الطعام بنسبة 30% في المؤسسات المشاركة</li>
                    </ul>
                  </div>
                </div>
                <div className="md:col-start-1"></div>
              </div>

              {/* 2029-2030 */}
              <div className="relative md:grid md:grid-cols-2">
                <div className="md:col-start-2 md:pl-12">
                  <div className="absolute hidden md:block right-1/2 top-5 -mr-3.5 h-7 w-7 rounded-full border-4 border-white bg-green-900"></div>
                  <div className="bg-green-50 p-6 rounded-lg shadow-sm border border-green-100 transform transition-transform duration-300 hover:-translate-y-1">
                    <h3 className="text-xl font-bold text-green-900 mb-2 text-right">2029-2030: تحقيق الرؤية</h3>
                    <ul className="list-disc list-inside text-gray-700 space-y-2 text-right">
                      <li>الوصول إلى هدف 50% خفض في هدر الطعام</li>
                      <li>تطوير نموذج مستدام ذاتيًا ماليًا</li>
                      <li>إطلاق منصة تبادل الخبرات مع دول عربية أخرى</li>
                      <li>المساهمة في تطوير سياسات وطنية لإدارة النفايات الغذائية</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Join the Movement */}
      <section className="py-16 bg-green-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">انضم إلى حركتنا</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            كل فرد يمكنه المساهمة في تحقيق رؤيتنا 2030 لمغرب خالٍ من هدر الطعام. 
            انضم إلينا اليوم وكن جزءًا من التغيير.
          </p>
          <div className="inline-flex rounded-md shadow">
            <a
              href="/register"
              className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-green-800 bg-white hover:bg-green-50 transition-colors"
            >
              سجل الآن وساهم معنا
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Vision2030;