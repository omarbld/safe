import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Clock, MapPin, Package, Calendar, User, AlertCircle, CheckCircle, Truck } from 'lucide-react';
import Button from '../../components/ui/Button';
import { Card, CardContent, CardFooter } from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import { mockDonations } from '../../data/mockData';
import { useAuth } from '../../context/AuthContext';
import { formatDistance } from 'date-fns';

const DonationDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { currentUser } = useAuth();
  
  const donation = mockDonations.find(d => d.id === id);
  
  if (!donation) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4\" dir="rtl">
        <div className="max-w-md bg-white rounded-lg shadow-md p-6 text-center">
          <AlertCircle className="h-16 w-16 text-amber-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">التبرع غير موجود</h1>
          <p className="text-gray-600 mb-6">التبرع الذي تبحث عنه غير موجود أو تم حذفه</p>
          <Link to="/donations">
            <Button>العودة إلى التبرعات</Button>
          </Link>
        </div>
      </div>
    );
  }
  
  const timeLeft = formatDistance(new Date(donation.expiryDate), new Date(), { addSuffix: true });
  const isExpiringSoon = new Date(donation.expiryDate).getTime() - Date.now() < 24 * 60 * 60 * 1000;
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'available':
        return <Badge variant="success\" className="text-base py-1 px-3">متاح</Badge>;
      case 'reserved':
        return <Badge variant="secondary" className="text-base py-1 px-3">محجوز</Badge>;
      case 'collected':
        return <Badge variant="primary" className="text-base py-1 px-3">تم الاستلام</Badge>;
      case 'delivered':
        return <Badge variant="success" className="text-base py-1 px-3">تم التوصيل</Badge>;
      case 'expired':
        return <Badge variant="danger" className="text-base py-1 px-3">منتهي الصلاحية</Badge>;
      default:
        return <Badge className="text-base py-1 px-3">غير معروف</Badge>;
    }
  };
  
  // Handle donation reservation
  const handleReserve = () => {
    alert(`تم طلب الحصول على التبرع "${donation.title}" بنجاح! سيتم التواصل مع المتطوعين للتوصيل.`);
  };
  
  // Handle volunteer offers
  const handleVolunteer = () => {
    alert(`تم تسجيل تطوعك لتوصيل "${donation.title}" بنجاح! سيتم التواصل معك قريباً.`);
  };
  
  const canReserve = currentUser?.role === 'charity' && donation.status === 'available';
  const canVolunteer = currentUser?.role === 'volunteer' && donation.status === 'reserved';
  
  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8" dir="rtl">
      <div className="max-w-4xl mx-auto">
        <Link to="/donations" className="inline-flex items-center text-green-700 hover:underline mb-6">
          &larr; العودة إلى قائمة التبرعات
        </Link>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="relative h-64 md:h-96">
            <img 
              src={donation.imageUrl || 'https://images.pexels.com/photos/6941028/pexels-photo-6941028.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'} 
              alt={donation.title}
              className="w-full h-full object-cover" 
            />
            <div className="absolute top-4 right-4">
              {getStatusBadge(donation.status)}
            </div>
          </div>
          
          <div className="p-6">
            <h1 className="text-3xl font-bold mb-4 text-right">{donation.title}</h1>
            
            <div className="flex items-center justify-end mb-6">
              <span className="text-gray-700">{donation.donorName}</span>
              <User size={18} className="ml-2 text-gray-500" />
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <p className="text-gray-700 text-right whitespace-pre-line">{donation.description}</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="flex items-center justify-end p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm text-gray-500">الكمية</p>
                  <p className="font-medium">{donation.quantity}</p>
                </div>
                <Package size={20} className="ml-3 text-green-600" />
              </div>
              
              <div className="flex items-center justify-end p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm text-gray-500">تاريخ الإضافة</p>
                  <p className="font-medium">
                    {new Date(donation.createdAt).toLocaleDateString('ar-MA')}
                  </p>
                </div>
                <Calendar size={20} className="ml-3 text-green-600" />
              </div>
              
              <div className="flex items-center justify-end p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm text-gray-500">ينتهي</p>
                  <p className={`font-medium ${isExpiringSoon ? 'text-red-600' : ''}`}>
                    {timeLeft}
                  </p>
                </div>
                <Clock size={20} className={`ml-3 ${isExpiringSoon ? 'text-red-600' : 'text-green-600'}`} />
              </div>
              
              <div className="flex items-center justify-end p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm text-gray-500">الموقع</p>
                  <p className="font-medium">الرباط، المغرب</p>
                </div>
                <MapPin size={20} className="ml-3 text-green-600" />
              </div>
            </div>
            
            {donation.status === 'reserved' && donation.reservedBy && (
              <div className="bg-amber-50 border border-amber-100 rounded-lg p-4 mb-6">
                <div className="flex items-center">
                  <CheckCircle className="text-amber-600 h-5 w-5 ml-2" />
                  <p className="text-amber-800">
                    تم حجز هذا التبرع من قبل جمعية خيرية وهو بانتظار التوصيل
                  </p>
                </div>
              </div>
            )}
            
            {(donation.status === 'collected' || donation.status === 'delivered') && donation.volunteerId && (
              <div className="bg-green-50 border border-green-100 rounded-lg p-4 mb-6">
                <div className="flex items-center">
                  <Truck className="text-green-600 h-5 w-5 ml-2" />
                  <p className="text-green-800">
                    {donation.status === 'collected' ? 
                      'تم استلام التبرع من المتبرع وهو الآن قيد التوصيل' :
                      'تم توصيل التبرع بنجاح للجهة المستفيدة'}
                  </p>
                </div>
              </div>
            )}
            
            <div className="flex justify-start mt-6 space-x-4 space-x-reverse">
              {canReserve && (
                <Button variant="primary\" onClick={handleReserve}>
                  طلب الحصول على التبرع
                </Button>
              )}
              
              {canVolunteer && (
                <Button variant="secondary" onClick={handleVolunteer}>
                  تطوع للتوصيل
                </Button>
              )}
              
              <Link to="/donations">
                <Button variant="outline">
                  عودة
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DonationDetails;