import React, { useState } from 'react';
import { Filter, Search } from 'lucide-react';
import DonationCard from '../../components/donations/DonationCard';
import { mockDonations } from '../../data/mockData';
import { useAuth } from '../../context/AuthContext';
import { Donation } from '../../types';

const DonationsList: React.FC = () => {
  const { currentUser } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<string>('all');
  const [showFilters, setShowFilters] = useState(false);
  
  // Handle donation reservation
  const handleReserve = (id: string) => {
    console.log(`Reserving donation with id: ${id}`);
    // Would make API call here to reserve donation
    alert(`تم طلب الحصول على التبرع بنجاح! سيتم التواصل مع المتطوعين للتوصيل.`);
  };
  
  // Filter donations based on search term and filter
  const filteredDonations = mockDonations
    .filter((donation) => {
      // Filter by status
      if (filter !== 'all' && donation.status !== filter) {
        return false;
      }
      
      // Filter by search term
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        return (
          donation.title.toLowerCase().includes(searchLower) ||
          donation.description.toLowerCase().includes(searchLower) ||
          donation.donorName.toLowerCase().includes(searchLower)
        );
      }
      
      return true;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  
  // Determine if the current user can reserve donations (only charities can)
  const canReserve = currentUser?.role === 'charity';
  
  return (
    <div dir="rtl">
      <div className="bg-green-700 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold mb-4 text-center">تبرعات الطعام المتاحة</h1>
          <p className="text-center text-lg max-w-3xl mx-auto">
            استعرض التبرعات المتاحة من المطاعم والمتاجر ويمكنك طلب الحصول عليها لتوزيعها على المحتاجين
          </p>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="relative flex-grow">
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pr-10 border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500 text-right"
                placeholder="ابحث عن تبرعات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <button
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-green-500"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="ml-2 -mr-1 h-5 w-5 text-gray-400" />
              فلترة
            </button>
          </div>
          
          {showFilters && (
            <div className="mt-4 p-4 bg-gray-50 rounded-md border border-gray-200">
              <div className="flex flex-wrap gap-2 justify-end">
                <button
                  className={`px-3 py-1 rounded-full text-sm ${
                    filter === 'all' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-700'
                  }`}
                  onClick={() => setFilter('all')}
                >
                  الكل
                </button>
                <button
                  className={`px-3 py-1 rounded-full text-sm ${
                    filter === 'available' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-700'
                  }`}
                  onClick={() => setFilter('available')}
                >
                  متاح
                </button>
                <button
                  className={`px-3 py-1 rounded-full text-sm ${
                    filter === 'reserved' ? 'bg-amber-500 text-white' : 'bg-gray-200 text-gray-700'
                  }`}
                  onClick={() => setFilter('reserved')}
                >
                  محجوز
                </button>
              </div>
            </div>
          )}
        </div>
        
        {filteredDonations.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDonations.map((donation) => (
              <DonationCard
                key={donation.id}
                donation={donation}
                onReserve={canReserve ? handleReserve : undefined}
                showReserve={canReserve}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-xl text-gray-600">لا توجد تبرعات متاحة حاليًا</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default DonationsList;