import React from 'react';
import { Link } from 'react-router-dom';
import { UtensilsCrossed, Truck, Heart, Users, Clock } from 'lucide-react';
import Button from '../components/ui/Button';
import { useAuth } from '../context/AuthContext';
import { mockStatistics } from '../data/mockData';

const Home: React.FC = () => {
  const { isAuthenticated } = useAuth();

  return (
    <div dir="rtl">
      {/* Hero Section */}
      <section className="relative bg-green-700 text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.pexels.com/photos/6941028/pexels-photo-6941028.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
            alt="طعام مغربي تقليدي"
            className="w-full h-full object-cover opacity-20"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32 relative z-10">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              مرحبًا بكم في منصة <span className="text-amber-400">SafeFood</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
              معًا نُحارب هدر الطعام في المغرب!
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              {!isAuthenticated && (
                <Link to="/register">
                  <Button variant="secondary\" size="lg">انضم الآن</Button>
                </Link>
              )}
              <Link to="/donations">
                <Button variant={isAuthenticated ? "primary" : "outline"} size="lg">تصفح التبرعات</Button>
              </Link>
            </div>
          </div>
        </div>
        
        {/* Stats Banner */}
        <div className="bg-white py-4 relative z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div className="p-2">
                <p className="text-green-700 text-3xl font-bold">{mockStatistics.totalDonations}+</p>
                <p className="text-gray-600">تبرع</p>
              </div>
              <div className="p-2">
                <p className="text-green-700 text-3xl font-bold">{mockStatistics.mealsServed}+</p>
                <p className="text-gray-600">وجبة تم إنقاذها</p>
              </div>
              <div className="p-2">
                <p className="text-green-700 text-3xl font-bold">{mockStatistics.totalVolunteers}+</p>
                <p className="text-gray-600">متطوع</p>
              </div>
              <div className="p-2">
                <p className="text-green-700 text-3xl font-bold">{mockStatistics.carbonSaved}+</p>
                <p className="text-gray-600">كجم من ثاني أكسيد الكربون</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How it works section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">كيف تعمل المنصة؟</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              منصة سهلة الاستخدام تربط بين المتبرعين بالطعام والجمعيات الخيرية والمتطوعين
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
            <div className="bg-white p-6 rounded-lg shadow-md text-center transition-transform duration-300 hover:-translate-y-2">
              <div className="w-16 h-16 bg-green-100 text-green-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <UtensilsCrossed size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">1. تبرع بالطعام</h3>
              <p className="text-gray-600">
                المطاعم والمتاجر تنشر تفاصيل فائض الطعام المتوفر لديها
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center transition-transform duration-300 hover:-translate-y-2">
              <div className="w-16 h-16 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">2. الجمعيات تطلب</h3>
              <p className="text-gray-600">
                الجمعيات الخيرية تطلب التبرعات المناسبة لاحتياجاتها
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center transition-transform duration-300 hover:-translate-y-2">
              <div className="w-16 h-16 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">3. التوصيل</h3>
              <p className="text-gray-600">
                المتطوعون يساعدون في نقل الطعام من المتبرعين إلى الجمعيات
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Join us section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">انضم إلينا اليوم</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              كن جزءًا من الحل لمشكلة هدر الطعام في المغرب. اختر دورك وساهم معنا
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-green-50 border border-green-100 p-6 rounded-lg transition-all duration-300 hover:shadow-md">
              <div className="text-green-700 mb-4">
                <UtensilsCrossed size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2 text-right">أنا مطعم / متجر</h3>
              <p className="text-gray-600 mb-4 text-right">
                تبرع بفائض الطعام لديك بدلاً من إهداره وساهم في خفض البصمة الكربونية
              </p>
              <Link to="/register" className="block text-right">
                <Button variant="primary">سجّل كمتبرع</Button>
              </Link>
            </div>
            
            <div className="bg-amber-50 border border-amber-100 p-6 rounded-lg transition-all duration-300 hover:shadow-md">
              <div className="text-amber-700 mb-4">
                <Users size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2 text-right">أنا جمعية خيرية</h3>
              <p className="text-gray-600 mb-4 text-right">
                احصل على تبرعات طعام لتوزيعها على المحتاجين بطريقة سهلة ومنظمة
              </p>
              <Link to="/register" className="block text-right">
                <Button variant="secondary">سجّل كجمعية</Button>
              </Link>
            </div>
            
            <div className="bg-blue-50 border border-blue-100 p-6 rounded-lg transition-all duration-300 hover:shadow-md">
              <div className="text-blue-700 mb-4">
                <Truck size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2 text-right">أنا متطوع</h3>
              <p className="text-gray-600 mb-4 text-right">
                ساعد في توصيل التبرعات من المتبرعين إلى الجمعيات وكن جزءًا من الحل
              </p>
              <Link to="/register" className="block text-right">
                <Button variant="outline">سجّل كمتطوع</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="bg-green-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">قم بالتغيير اليوم</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            معًا يمكننا خفض هدر الطعام ومساعدة المحتاجين. كل تبرع صغير يحدث فرقًا كبيرًا.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/register">
              <Button variant="secondary" size="lg">انضم إلينا</Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline" size="lg">تواصل معنا</Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;