import React from 'react';
import { Link } from 'react-router-dom';
import LoginForm from '../../components/auth/LoginForm';

const Login: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8" dir="rtl">
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden">
        <div className="bg-green-700 px-6 py-8 text-center text-white">
          <h2 className="text-2xl font-bold">تسجيل الدخول</h2>
          <p className="mt-2 text-green-100">أهلاً بك مجدداً في منصة SafeFood</p>
        </div>
        
        <div className="px-6 py-8">
          <LoginForm />
          
          <div className="mt-6 text-center text-sm">
            <p className="text-gray-600">
              ليس لديك حساب؟{' '}
              <Link to="/register" className="text-green-700 hover:underline font-medium">
                إنشاء حساب جديد
              </Link>
            </p>
          </div>
        </div>
        
        {/* Debug login details - would be removed in production */}
        <div className="bg-amber-50 p-4 border-t border-amber-100">
          <p className="text-amber-800 text-sm font-medium mb-2">بيانات تجريبية للدخول:</p>
          <ul className="text-sm text-gray-700 space-y-1">
            <li><strong>متبرع:</strong> donor@example.com / password</li>
            <li><strong>جمعية:</strong> charity@example.com / password</li>
            <li><strong>متطوع:</strong> volunteer@example.com / password</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Login;