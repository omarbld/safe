import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });
  
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess(false);
    setLoading(true);
    
    // Simulate form submission
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      setFormData({
        name: '',
        email: '',
        message: '',
      });
    }, 1000);
  };
  
  return (
    <div dir="rtl">
      {/* Hero Section */}
      <section className="bg-green-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6">تواصل معنا</h1>
          <p className="text-xl max-w-3xl mx-auto">
            نحن هنا للإجابة على استفساراتك ومساعدتك في المشاركة في مبادرة SafeFood
          </p>
        </div>
      </section>
      
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-2xl font-bold mb-6 text-gray-900 text-right">معلومات التواصل</h2>
              
              <div className="space-y-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-green-100 flex items-center justify-center ml-4">
                    <Mail className="h-6 w-6 text-green-700" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">البريد الإلكتروني</h3>
                    <a href="mailto:info@safefood.ma" className="text-gray-600 hover:text-green-700">
                      info@safefood.ma
                    </a>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-green-100 flex items-center justify-center ml-4">
                    <Phone className="h-6 w-6 text-green-700" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">الهاتف</h3>
                    <a href="tel:+212522000000" className="text-gray-600 hover:text-green-700">
                      +212 522 000 000
                    </a>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-green-100 flex items-center justify-center ml-4">
                    <MapPin className="h-6 w-6 text-green-700" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">العنوان</h3>
                    <p className="text-gray-600">
                      شارع محمد الخامس، الرباط، المغرب
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-12">
                <h3 className="text-lg font-bold mb-4 text-gray-900">ساعات العمل</h3>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">الإثنين - الجمعة</span>
                    <span className="text-gray-900 font-medium">9:00 صباحًا - 5:00 مساءً</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">السبت</span>
                    <span className="text-gray-900 font-medium">10:00 صباحًا - 2:00 مساءً</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">الأحد</span>
                    <span className="text-gray-900 font-medium">مغلق</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <h2 className="text-2xl font-bold mb-6 text-gray-900 text-right">أرسل لنا رسالة</h2>
              
              <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-lg shadow-sm">
                {error && (
                  <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-right">
                    {error}
                  </div>
                )}
                
                {success && (
                  <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4 text-right">
                    تم إرسال رسالتك بنجاح! سنتواصل معك قريبًا.
                  </div>
                )}
                
                <Input
                  label="الاسم الكامل"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="أدخل اسمك الكامل"
                  required
                  fullWidth
                />
                
                <Input
                  label="البريد الإلكتروني"
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="أدخل بريدك الإلكتروني"
                  required
                  fullWidth
                />
                
                <div className="mb-4">
                  <label className="block text-gray-700 font-medium mb-1 text-right">
                    الرسالة
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="اكتب رسالتك هنا..."
                    rows={6}
                    required
                    className="block w-full px-4 py-2 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600 outline-none transition-colors"
                  ></textarea>
                </div>
                
                <div className="flex justify-end">
                  <Button
                    type="submit"
                    variant="primary"
                    loading={loading}
                    icon={!loading && <Send size={16} />}
                  >
                    إرسال الرسالة
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
      
      {/* Map */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gray-200 rounded-lg h-96 overflow-hidden">
            <div className="h-full w-full flex items-center justify-center bg-gray-300">
              <div className="text-center">
                <MapPin size={48} className="mx-auto mb-2 text-gray-400" />
                <p className="text-gray-600">خريطة الموقع</p>
                <p className="text-sm text-gray-500">(ستظهر هنا خريطة تفاعلية في الإصدار النهائي)</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* FAQ Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold mb-8 text-center text-gray-900">الأسئلة الشائعة</h2>
          
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-2">كيف يمكنني التبرع بالطعام الفائض؟</h3>
              <p className="text-gray-600">
                يمكنك التسجيل كمتبرع في المنصة، ثم إضافة تفاصيل التبرع من خلال لوحة التحكم الخاصة بك.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-2">هل يمكنني التطوع في التوصيل فقط في أوقات معينة؟</h3>
              <p className="text-gray-600">
                نعم، يمكنك تحديد الأوقات المناسبة لك للتطوع في ملفك الشخصي، وسيتم إشعارك فقط بالمهام المتاحة في هذه الأوقات.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-2">هل يوجد تكلفة للاشتراك في المنصة؟</h3>
              <p className="text-gray-600">
                لا، الاشتراك في منصة SafeFood مجاني تمامًا لجميع الأطراف. نحن منصة غير ربحية تهدف لخدمة المجتمع.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-2">كيف يتم ضمان جودة وسلامة الطعام؟</h3>
              <p className="text-gray-600">
                نطلب من جميع المتبرعين الالتزام بمعايير السلامة الغذائية وتقديم معلومات دقيقة حول تاريخ انتهاء الصلاحية. كما نقوم بمراجعة دورية للتبرعات.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;