import React from 'react';
import { Heart, UtensilsCrossed, Truck, Globe, Award, Users } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div dir="rtl">
      {/* Hero Section */}
      <section className="bg-green-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6">من نحن</h1>
          <p className="text-xl max-w-3xl mx-auto">
            منصة SafeFood هي مبادرة مغربية تهدف إلى مكافحة هدر الطعام وإيصاله للمحتاجين
          </p>
        </div>
      </section>
      
      {/* Mission Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6 text-right">مهمتنا</h2>
              <p className="text-lg text-gray-600 mb-4 text-right">
                في SafeFood، نسعى لإيجاد حلول مستدامة لمشكلة هدر الطعام في المغرب من خلال ربط أصحاب فائض الطعام مع المحتاجين إليه.
              </p>
              <p className="text-lg text-gray-600 mb-4 text-right">
                رؤيتنا هي مجتمع مغربي خالٍ من هدر الطعام، حيث يصل كل طعام صالح للاستهلاك إلى طبق شخص يحتاجه بدلاً من النفايات.
              </p>
              <div className="border-r-4 border-green-600 pr-4 mt-6">
                <p className="text-xl font-medium text-gray-800 text-right">
                  "لا نملك الحق في إهدار الطعام بينما يوجد من هو في حاجة إليه"
                </p>
              </div>
            </div>
            
            <div className="relative h-96 rounded-lg overflow-hidden">
              <img 
                src="https://images.pexels.com/photos/6647037/pexels-photo-6647037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="متطوعون يقدمون الطعام" 
                className="w-full h-full object-cover" 
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Values Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">قيمنا</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              نسترشد بمجموعة من القيم الأساسية التي تشكل كل ما نقوم به
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="w-16 h-16 bg-green-100 text-green-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">التعاطف</h3>
              <p className="text-gray-600">
                نؤمن بأهمية العمل بتعاطف تجاه جميع أفراد المجتمع ومساعدة المحتاجين
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="w-16 h-16 bg-green-100 text-green-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">الاستدامة</h3>
              <p className="text-gray-600">
                نعمل على تقليل البصمة البيئية وتعزيز الممارسات المستدامة في مجتمعنا
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="w-16 h-16 bg-green-100 text-green-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">النزاهة</h3>
              <p className="text-gray-600">
                نلتزم بالشفافية والمسؤولية في كل تعاملاتنا مع المتبرعين والمستفيدين
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Team Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">فريقنا</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              نحن مجموعة من المتحمسين الذين يؤمنون بإمكانية إحداث تغيير إيجابي في مجتمعنا
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="w-24 h-24 rounded-full overflow-hidden mx-auto mb-4 bg-gray-200">
                <img
                  src="https://images.pexels.com/photos/2381069/pexels-photo-2381069.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                  alt="Founder"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-bold mb-1">كريم العلوي</h3>
              <p className="text-green-700 mb-3">المؤسس والرئيس التنفيذي</p>
              <p className="text-gray-600">
                خبير في مجال الاستدامة الغذائية مع خبرة 10 سنوات في مجال الأمن الغذائي
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="w-24 h-24 rounded-full overflow-hidden mx-auto mb-4 bg-gray-200">
                <img
                  src="https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                  alt="Tech Lead"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-bold mb-1">سارة بنعمر</h3>
              <p className="text-green-700 mb-3">مديرة التكنولوجيا</p>
              <p className="text-gray-600">
                مهندسة برمجيات متخصصة في تطوير المنصات الرقمية ذات التأثير الاجتماعي
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="w-24 h-24 rounded-full overflow-hidden mx-auto mb-4 bg-gray-200">
                <img
                  src="https://images.pexels.com/photos/2962144/pexels-photo-2962144.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                  alt="Operations Manager"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-bold mb-1">يوسف الناصري</h3>
              <p className="text-green-700 mb-3">مدير العمليات</p>
              <p className="text-gray-600">
                متخصص في الخدمات اللوجستية وإدارة المتطوعين مع خبرة في المنظمات غير الربحية
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Partners Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">شركاؤنا</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              نفخر بالعمل مع مجموعة من المنظمات والشركات الملتزمة بمكافحة هدر الطعام
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="flex items-center justify-center p-6 bg-white rounded-lg shadow-sm">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-3 opacity-70">
                  <UtensilsCrossed size={64} className="text-gray-600" />
                </div>
                <p className="font-medium">اتحاد المطاعم المغربية</p>
              </div>
            </div>
            
            <div className="flex items-center justify-center p-6 bg-white rounded-lg shadow-sm">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-3 opacity-70">
                  <Heart size={64} className="text-gray-600" />
                </div>
                <p className="font-medium">جمعية الخير المغربية</p>
              </div>
            </div>
            
            <div className="flex items-center justify-center p-6 bg-white rounded-lg shadow-sm">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-3 opacity-70">
                  <Truck size={64} className="text-gray-600" />
                </div>
                <p className="font-medium">شركة التوصيل السريع</p>
              </div>
            </div>
            
            <div className="flex items-center justify-center p-6 bg-white rounded-lg shadow-sm">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-3 opacity-70">
                  <Users size={64} className="text-gray-600" />
                </div>
                <p className="font-medium">مؤسسة دعم المجتمع</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;