import React, { useState } from 'react';
import { Plus, ShoppingBag, Clock, AlertTriangle } from 'lucide-react';
import DonationCard from '../../components/donations/DonationCard';
import DonationForm from '../../components/donations/DonationForm';
import StatCard from '../../components/dashboard/StatCard';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { mockDonations } from '../../data/mockData';
import { useAuth } from '../../context/AuthContext';

const DonorDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [showDonationForm, setShowDonationForm] = useState(false);
  
  // Filter donations to only show the current donor's donations
  const myDonations = mockDonations.filter(donation => donation.donorId === currentUser?.id);
  
  const handleDonationSubmit = (formData: any) => {
    console.log('Donation form submitted:', formData);
    // Would make API call here
    setShowDonationForm(false);
    alert('تم إضافة التبرع بنجاح!');
  };
  
  // Stats for the donor
  const donorStats = {
    totalDonations: myDonations.length,
    availableDonations: myDonations.filter(d => d.status === 'available').length,
    reservedDonations: myDonations.filter(d => d.status === 'reserved' || d.status === 'collected').length,
    deliveredDonations: myDonations.filter(d => d.status === 'delivered').length,
    expiringDonations: myDonations.filter(d => {
      const expiryDate = new Date(d.expiryDate);
      return expiryDate.getTime() - Date.now() < 24 * 60 * 60 * 1000 && d.status === 'available';
    }).length
  };
  
  return (
    <div className="p-6" dir="rtl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-1">مرحبًا، {currentUser?.name}</h1>
          <p className="text-gray-600">لوحة تحكم المتبرع بالطعام</p>
        </div>
        
        <Button
          variant="primary"
          icon={<Plus size={16} />}
          onClick={() => setShowDonationForm(true)}
          className="mt-4 md:mt-0"
        >
          تبرع جديد
        </Button>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard
          title="إجمالي تبرعاتك"
          value={donorStats.totalDonations}
          icon={<ShoppingBag size={24} />}
        />
        <StatCard
          title="تبرعات متاحة"
          value={donorStats.availableDonations}
          icon={<ShoppingBag size={24} />}
        />
        <StatCard
          title="تبرعات تم توصيلها"
          value={donorStats.deliveredDonations}
          icon={<ShoppingBag size={24} />}
        />
        <StatCard
          title="تبرعات قاربت على الانتهاء"
          value={donorStats.expiringDonations}
          icon={<Clock size={24} />}
          trend={donorStats.expiringDonations > 0 ? { value: donorStats.expiringDonations, isPositive: false } : undefined}
        />
      </div>
      
      {/* Donation Form */}
      {showDonationForm && (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>إضافة تبرع جديد</CardTitle>
          </CardHeader>
          <CardContent>
            <DonationForm onSubmit={handleDonationSubmit} />
          </CardContent>
        </Card>
      )}
      
      {/* Expiring Soon Alert */}
      {donorStats.expiringDonations > 0 && (
        <div className="bg-amber-50 border-l-4 border-amber-500 p-4 mb-8 rounded-md">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
            </div>
            <div className="ml-3">
              <h3 className="text-amber-800 font-medium">تنبيه: تبرعات قاربت على انتهاء الصلاحية</h3>
              <p className="text-amber-700 mt-1">
                لديك {donorStats.expiringDonations} {donorStats.expiringDonations === 1 ? 'تبرع' : 'تبرعات'} {' '}
                ستنتهي صلاحيته قريبًا. نوصي بتذكير الجمعيات الخيرية أو تحديث حالة التبرع.
              </p>
            </div>
          </div>
        </div>
      )}
      
      {/* My Donations */}
      <h2 className="text-xl font-bold text-gray-900 mb-4">تبرعاتي</h2>
      
      {myDonations.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {myDonations.map((donation) => (
            <DonationCard
              key={donation.id}
              donation={donation}
              showReserve={false}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white p-6 rounded-lg shadow-sm text-center">
          <p className="text-gray-600 mb-4">لم تقم بإضافة أي تبرعات حتى الآن</p>
          <Button 
            variant="primary" 
            icon={<Plus size={16} />}
            onClick={() => setShowDonationForm(true)}
          >
            إضافة تبرع جديد
          </Button>
        </div>
      )}
    </div>
  );
};

export default DonorDashboard;