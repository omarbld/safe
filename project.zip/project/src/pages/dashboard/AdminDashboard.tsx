import React from 'react';
import { Link } from 'react-router-dom';
import { UtensilsCrossed, Users, UserCheck, ShoppingBag, TrendingUp, Download } from 'lucide-react';
import StatCard from '../../components/dashboard/StatCard';
import Button from '../../components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';
import { mockStatistics, mockDonations } from '../../data/mockData';

// Mock monthly data for charts
const mockMonthlyData = {
  donations: [12, 19, 15, 8, 22, 30, 25, 18, 14, 28, 32, 24],
  users: [5, 8, 12, 15, 10, 7, 14, 18, 20, 16, 12, 18],
};

const AdminDashboard: React.FC = () => {
  // Get donations by status
  const donationsByStatus = {
    available: mockDonations.filter(d => d.status === 'available').length,
    reserved: mockDonations.filter(d => d.status === 'reserved').length,
    collected: mockDonations.filter(d => d.status === 'collected').length,
    delivered: mockDonations.filter(d => d.status === 'delivered').length,
    expired: mockDonations.filter(d => d.status === 'expired').length,
  };
  
  const handleExportData = () => {
    alert('تم تصدير البيانات إلى ملف Excel بنجاح!');
  };
  
  return (
    <div className="p-6" dir="rtl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-1">لوحة تحكم المدير</h1>
          <p className="text-gray-600">نظرة عامة على النظام والإحصائيات</p>
        </div>
        
        <div className="flex space-x-2 space-x-reverse mt-4 md:mt-0">
          <Button
            variant="outline"
            icon={<Download size={16} />}
            onClick={handleExportData}
          >
            تصدير البيانات
          </Button>
        </div>
      </div>
      
      {/* Main Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard
          title="إجمالي التبرعات"
          value={mockStatistics.totalDonations}
          icon={<ShoppingBag size={24} />}
          trend={{ value: 12, isPositive: true }}
        />
        <StatCard
          title="المتبرعين"
          value={mockStatistics.totalDonors}
          icon={<UtensilsCrossed size={24} />}
          trend={{ value: 5, isPositive: true }}
        />
        <StatCard
          title="الجمعيات الخيرية"
          value={mockStatistics.totalCharities}
          icon={<Users size={24} />}
          trend={{ value: 8, isPositive: true }}
        />
        <StatCard
          title="المتطوعين"
          value={mockStatistics.totalVolunteers}
          icon={<UserCheck size={24} />}
          trend={{ value: 15, isPositive: true }}
        />
      </div>
      
      {/* Donations by Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>حالة التبرعات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center">
                <span className="w-24 text-sm text-gray-500">متاح</span>
                <div className="flex-1">
                  <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-green-500"
                      style={{ width: `${(donationsByStatus.available / mockStatistics.totalDonations) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <span className="w-12 text-right font-medium">{donationsByStatus.available}</span>
              </div>
              
              <div className="flex items-center">
                <span className="w-24 text-sm text-gray-500">محجوز</span>
                <div className="flex-1">
                  <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-amber-500"
                      style={{ width: `${(donationsByStatus.reserved / mockStatistics.totalDonations) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <span className="w-12 text-right font-medium">{donationsByStatus.reserved}</span>
              </div>
              
              <div className="flex items-center">
                <span className="w-24 text-sm text-gray-500">قيد التوصيل</span>
                <div className="flex-1">
                  <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-500"
                      style={{ width: `${(donationsByStatus.collected / mockStatistics.totalDonations) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <span className="w-12 text-right font-medium">{donationsByStatus.collected}</span>
              </div>
              
              <div className="flex items-center">
                <span className="w-24 text-sm text-gray-500">تم التوصيل</span>
                <div className="flex-1">
                  <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-green-700"
                      style={{ width: `${(donationsByStatus.delivered / mockStatistics.totalDonations) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <span className="w-12 text-right font-medium">{donationsByStatus.delivered}</span>
              </div>
              
              <div className="flex items-center">
                <span className="w-24 text-sm text-gray-500">منتهي الصلاحية</span>
                <div className="flex-1">
                  <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-red-500"
                      style={{ width: `${(donationsByStatus.expired / mockStatistics.totalDonations) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <span className="w-12 text-right font-medium">{donationsByStatus.expired}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>إحصائيات التأثير</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <h4 className="text-sm text-gray-500 mb-1">إجمالي الوجبات التي تم إنقاذها</h4>
                <div className="flex items-center">
                  <span className="text-3xl font-bold text-gray-900">{mockStatistics.mealsServed}</span>
                  <span className="text-sm text-green-600 font-medium mr-2">
                    <TrendingUp size={16} className="inline mr-1" />
                    +18% منذ الشهر الماضي
                  </span>
                </div>
              </div>
              
              <div>
                <h4 className="text-sm text-gray-500 mb-1">توفير ثاني أكسيد الكربون</h4>
                <div className="flex items-center">
                  <span className="text-3xl font-bold text-gray-900">{mockStatistics.carbonSaved}</span>
                  <span className="text-sm text-gray-600 mr-2">كجم من CO2</span>
                  <span className="text-sm text-green-600 font-medium mr-2">
                    <TrendingUp size={16} className="inline mr-1" />
                    +12% منذ الشهر الماضي
                  </span>
                </div>
              </div>
              
              <div className="pt-4 border-t">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-sm text-gray-500">معدل نمو التبرعات الشهري</h4>
                  <span className="text-sm text-green-600">+24%</span>
                </div>
                <div className="h-12 flex items-end space-x-1 space-x-reverse">
                  {mockMonthlyData.donations.map((value, index) => (
                    <div
                      key={index}
                      className="w-full bg-green-200 hover:bg-green-300 transition-colors rounded-t"
                      style={{ height: `${(value / Math.max(...mockMonthlyData.donations)) * 100}%` }}
                      title={`شهر ${index + 1}: ${value} تبرع`}
                    ></div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>آخر التبرعات</CardTitle>
            <Link to="/donations" className="text-sm text-green-700 hover:underline">
              عرض الكل
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">التبرع</th>
                  <th className="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">المتبرع</th>
                  <th className="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الحالة</th>
                  <th className="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">التاريخ</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {mockDonations.slice(0, 5).map((donation) => (
                  <tr key={donation.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{donation.title}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{donation.donorName}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                        donation.status === 'available' ? 'bg-green-100 text-green-800' :
                        donation.status === 'reserved' ? 'bg-amber-100 text-amber-800' :
                        donation.status === 'delivered' ? 'bg-blue-100 text-blue-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {donation.status === 'available' ? 'متاح' :
                         donation.status === 'reserved' ? 'محجوز' :
                         donation.status === 'collected' ? 'قيد التوصيل' :
                         donation.status === 'delivered' ? 'تم التوصيل' :
                         'منتهي الصلاحية'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(donation.createdAt).toLocaleDateString('ar-MA')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDashboard;