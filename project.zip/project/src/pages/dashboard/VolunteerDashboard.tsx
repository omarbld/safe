import React from 'react';
import { Truck, MapPin, CheckCheck, Award } from 'lucide-react';
import { Link } from 'react-router-dom';
import Button from '../../components/ui/Button';
import StatCard from '../../components/dashboard/StatCard';
import { Card, CardContent } from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import { mockDonations } from '../../data/mockData';
import { useAuth } from '../../context/AuthContext';

const VolunteerDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  
  // Filter donations to get volunteer missions
  const myMissions = mockDonations.filter(donation => 
    donation.volunteerId === currentUser?.id
  );
  
  // Get available missions (donations that are reserved but don't have a volunteer)
  const availableMissions = mockDonations.filter(donation => 
    donation.status === 'reserved' && !donation.volunteerId
  );
  
  // Stats for the volunteer
  const volunteerStats = {
    totalDeliveries: myMissions.filter(m => m.status === 'delivered').length,
    activeMissions: myMissions.filter(m => m.status === 'collected').length,
    availableMissions: availableMissions.length,
    rating: 4.8, // Mock data
  };
  
  const handleAcceptMission = (id: string) => {
    console.log(`Accepting mission for donation ${id}`);
    // Would make API call here
    alert('تم قبول المهمة بنجاح! يرجى التواصل مع المتبرع لتنسيق استلام التبرع.');
  };
  
  const handleCompleteMission = (id: string) => {
    console.log(`Completing mission for donation ${id}`);
    // Would make API call here
    alert('تم تأكيد توصيل التبرع بنجاح! شكرًا لمساهمتك.');
  };
  
  return (
    <div className="p-6" dir="rtl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-1">مرحبًا، {currentUser?.name}</h1>
          <p className="text-gray-600">لوحة تحكم المتطوع</p>
        </div>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard
          title="توصيلات مكتملة"
          value={volunteerStats.totalDeliveries}
          icon={<CheckCheck size={24} />}
        />
        <StatCard
          title="مهام نشطة"
          value={volunteerStats.activeMissions}
          icon={<Truck size={24} />}
        />
        <StatCard
          title="مهام متاحة قريبة منك"
          value={volunteerStats.availableMissions}
          icon={<MapPin size={24} />}
        />
        <StatCard
          title="تقييمك"
          value={volunteerStats.rating}
          icon={<Award size={24} />}
          suffix="/ 5"
        />
      </div>
      
      {/* Active Missions */}
      <h2 className="text-xl font-bold text-gray-900 mb-4">مهامي النشطة</h2>
      
      {myMissions.filter(m => m.status === 'collected').length > 0 ? (
        <div className="space-y-4 mb-8">
          {myMissions
            .filter(m => m.status === 'collected')
            .map((mission) => (
              <Card key={mission.id} className="overflow-hidden">
                <div className="flex flex-col md:flex-row">
                  <div className="w-full md:w-32 h-32 overflow-hidden">
                    <img
                      src={mission.imageUrl || 'https://images.pexels.com/photos/6941028/pexels-photo-6941028.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'}
                      alt={mission.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="flex-grow flex flex-col md:flex-row items-center justify-between p-4">
                    <div className="text-center md:text-right mb-4 md:mb-0">
                      <div className="flex items-center justify-center md:justify-end mb-2">
                        <h3 className="font-bold text-lg">{mission.title}</h3>
                        <Badge variant="primary" className="mr-2">قيد التوصيل</Badge>
                      </div>
                      <p className="text-gray-600 mb-2">من: {mission.donorName}</p>
                      <p className="text-gray-600">إلى: جمعية الخير للجميع</p>
                    </div>
                    <div>
                      <Button 
                        variant="success" 
                        onClick={() => handleCompleteMission(mission.id)}
                      >
                        تأكيد التوصيل
                      </Button>
                    </div>
                  </CardContent>
                </div>
              </Card>
            ))}
        </div>
      ) : (
        <div className="bg-white p-6 rounded-lg shadow-sm text-center mb-8">
          <p className="text-gray-600">ليس لديك أي مهام نشطة حاليًا</p>
        </div>
      )}
      
      {/* Available Missions */}
      <h2 className="text-xl font-bold text-gray-900 mb-4">مهام متاحة قريبة منك</h2>
      
      {availableMissions.length > 0 ? (
        <div className="space-y-4">
          {availableMissions.map((mission) => (
            <Card key={mission.id} className="overflow-hidden">
              <div className="flex flex-col md:flex-row">
                <div className="w-full md:w-32 h-32 overflow-hidden">
                  <img
                    src={mission.imageUrl || 'https://images.pexels.com/photos/6941028/pexels-photo-6941028.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'}
                    alt={mission.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="flex-grow flex flex-col md:flex-row items-center justify-between p-4">
                  <div className="text-center md:text-right mb-4 md:mb-0">
                    <div className="flex items-center justify-center md:justify-end mb-2">
                      <h3 className="font-bold text-lg">{mission.title}</h3>
                      <Badge variant="secondary" className="mr-2">بانتظار متطوع</Badge>
                    </div>
                    <p className="text-gray-600 mb-2">من: {mission.donorName}</p>
                    <p className="text-gray-600">إلى: جمعية الخير للجميع</p>
                    <p className="text-gray-500 text-sm mt-1">المسافة: ~3 كم</p>
                  </div>
                  <div>
                    <Button 
                      variant="primary" 
                      onClick={() => handleAcceptMission(mission.id)}
                    >
                      قبول المهمة
                    </Button>
                  </div>
                </CardContent>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <div className="bg-white p-6 rounded-lg shadow-sm text-center">
          <p className="text-gray-600">لا توجد مهام متاحة حاليًا</p>
        </div>
      )}
    </div>
  );
};

export default VolunteerDashboard;