import React from 'react';
import { ShoppingBag, Truck, Check, Calendar } from 'lucide-react';
import DonationCard from '../../components/donations/DonationCard';
import StatCard from '../../components/dashboard/StatCard';
import Button from '../../components/ui/Button';
import { Link } from 'react-router-dom';
import { mockDonations } from '../../data/mockData';
import { useAuth } from '../../context/AuthContext';

const CharityDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  
  // Filter donations to only show the ones reserved by this charity
  const myReservations = mockDonations.filter(donation => 
    donation.reservedBy === currentUser?.id
  );
  
  // Stats for the charity
  const charityStats = {
    totalReserved: myReservations.length,
    pending: myReservations.filter(d => d.status === 'reserved').length,
    collected: myReservations.filter(d => d.status === 'collected').length,
    delivered: myReservations.filter(d => d.status === 'delivered').length,
    peopleServed: myReservations.filter(d => d.status === 'delivered').length * 15, // Approximation
  };
  
  return (
    <div className="p-6" dir="rtl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-1">مرحبًا، {currentUser?.name}</h1>
          <p className="text-gray-600">لوحة تحكم الجمعية الخيرية</p>
        </div>
        
        <Link to="/donations" className="mt-4 md:mt-0">
          <Button variant="primary">تصفح التبرعات المتاحة</Button>
        </Link>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard
          title="إجمالي الطلبات"
          value={charityStats.totalReserved}
          icon={<ShoppingBag size={24} />}
        />
        <StatCard
          title="قيد الانتظار"
          value={charityStats.pending}
          icon={<Calendar size={24} />}
        />
        <StatCard
          title="تم التوصيل"
          value={charityStats.delivered}
          icon={<Check size={24} />}
        />
        <StatCard
          title="أشخاص تم إطعامهم"
          value={charityStats.peopleServed}
          icon={<Truck size={24} />}
          suffix="شخص"
        />
      </div>
      
      {/* My Reservations */}
      <h2 className="text-xl font-bold text-gray-900 mb-4">طلباتي</h2>
      
      {myReservations.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {myReservations.map((donation) => (
            <DonationCard
              key={donation.id}
              donation={donation}
              showReserve={false}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white p-6 rounded-lg shadow-sm text-center">
          <p className="text-gray-600 mb-4">لم تقم بطلب أي تبرعات حتى الآن</p>
          <Link to="/donations">
            <Button variant="primary">تصفح التبرعات المتاحة</Button>
          </Link>
        </div>
      )}
    </div>
  );
};

export default CharityDashboard;