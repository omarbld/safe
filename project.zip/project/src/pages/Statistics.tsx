import React from 'react';
import { PackageOpen, UtensilsCrossed, Users, Truck, TrendingUp, Clock, User } from 'lucide-react';
import { mockStatistics } from '../data/mockData';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';

const Statistics: React.FC = () => {
  // Sample data for visualizations
  const monthlyData = {
    labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
    donations: [14, 22, 25, 20, 18, 32, 35, 40, 42, 45, 48, 52],
    volunteers: [5, 8, 10, 12, 15, 18, 22, 25, 27, 30, 32, 35],
  };

  // Cities data
  const citiesData = [
    { name: 'الرباط', percentage: 35 },
    { name: 'الدار البيضاء', percentage: 28 },
    { name: 'مراكش', percentage: 15 },
    { name: 'طنجة', percentage: 12 },
    { name: 'فاس', percentage: 10 },
  ];

  // Food types data
  const foodTypesData = [
    { type: 'وجبات كاملة', percentage: 42 },
    { type: 'خبز ومعجنات', percentage: 25 },
    { type: 'فواكه وخضروات', percentage: 18 },
    { type: 'حلويات', percentage: 10 },
    { type: 'أخرى', percentage: 5 },
  ];

  return (
    <div dir="rtl">
      {/* Hero Section */}
      <section className="bg-green-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6">إحصائيات التأثير</h1>
          <p className="text-xl max-w-3xl mx-auto">
            نتائج مبادرة SafeFood في مكافحة هدر الطعام بالمغرب
          </p>
        </div>
      </section>
      
      {/* Key Statistics */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-green-50 p-6 rounded-lg shadow-sm text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-green-100 text-green-700 rounded-full mb-4">
                <PackageOpen size={24} />
              </div>
              <h3 className="text-3xl font-bold mb-1">{mockStatistics.totalDonations}+</h3>
              <p className="text-gray-600">إجمالي التبرعات</p>
            </div>
            
            <div className="bg-blue-50 p-6 rounded-lg shadow-sm text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 text-blue-700 rounded-full mb-4">
                <UtensilsCrossed size={24} />
              </div>
              <h3 className="text-3xl font-bold mb-1">{mockStatistics.mealsServed}+</h3>
              <p className="text-gray-600">وجبة تم إنقاذها</p>
            </div>
            
            <div className="bg-amber-50 p-6 rounded-lg shadow-sm text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-amber-100 text-amber-700 rounded-full mb-4">
                <Users size={24} />
              </div>
              <h3 className="text-3xl font-bold mb-1">{mockStatistics.totalVolunteers}+</h3>
              <p className="text-gray-600">متطوع نشط</p>
            </div>
            
            <div className="bg-green-50 p-6 rounded-lg shadow-sm text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-green-100 text-green-700 rounded-full mb-4">
                <TrendingUp size={24} />
              </div>
              <h3 className="text-3xl font-bold mb-1">{mockStatistics.carbonSaved}+</h3>
              <p className="text-gray-600">كجم من ثاني أكسيد الكربون تم توفيرها</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Charts and Graphs */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">تحليل البيانات</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Monthly Trends */}
            <Card>
              <CardHeader>
                <CardTitle>نمو التبرعات الشهري</CardTitle>
              </CardHeader>
              <CardContent className="h-80">
                <div className="h-full flex items-end space-x-2 space-x-reverse">
                  {monthlyData.donations.map((value, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div 
                        className="w-full bg-green-200 hover:bg-green-300 transition-all duration-300 rounded-t"
                        style={{ height: `${(value / Math.max(...monthlyData.donations)) * 100}%` }}
                        title={`${monthlyData.labels[index]}: ${value} تبرع`}
                      ></div>
                      <span className="text-xs mt-1 text-gray-500">{monthlyData.labels[index].substring(0, 3)}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Volunteers Growth */}
            <Card>
              <CardHeader>
                <CardTitle>نمو عدد المتطوعين</CardTitle>
              </CardHeader>
              <CardContent className="h-80">
                <div className="h-full flex items-end space-x-2 space-x-reverse">
                  {monthlyData.volunteers.map((value, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div 
                        className="w-full bg-blue-200 hover:bg-blue-300 transition-all duration-300 rounded-t"
                        style={{ height: `${(value / Math.max(...monthlyData.volunteers)) * 100}%` }}
                        title={`${monthlyData.labels[index]}: ${value} متطوع`}
                      ></div>
                      <span className="text-xs mt-1 text-gray-500">{monthlyData.labels[index].substring(0, 3)}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Distribution by Cities */}
            <Card>
              <CardHeader>
                <CardTitle>التوزيع حسب المدن</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {citiesData.map((city, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-gray-700">{city.name}</span>
                        <span className="text-sm text-gray-500">{city.percentage}%</span>
                      </div>
                      <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-green-500 to-green-700"
                          style={{ width: `${city.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Food Types */}
            <Card>
              <CardHeader>
                <CardTitle>أنواع الطعام المتبرع به</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {foodTypesData.map((food, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-gray-700">{food.type}</span>
                        <span className="text-sm text-gray-500">{food.percentage}%</span>
                      </div>
                      <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-amber-400 to-amber-600"
                          style={{ width: `${food.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
      
      {/* Impact Metrics */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">تأثيرنا البيئي والاجتماعي</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="mb-4 inline-flex items-center justify-center w-16 h-16 bg-green-100 text-green-700 rounded-full">
                  <Clock size={32} />
                </div>
                <h3 className="text-2xl font-bold mb-2">2,450</h3>
                <p className="text-xl font-medium text-green-700 mb-4">ساعة تطوعية</p>
                <p className="text-gray-600">
                  مجموع ساعات التطوع التي قدمها متطوعونا في توصيل وتوزيع الطعام
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <div className="mb-4 inline-flex items-center justify-center w-16 h-16 bg-amber-100 text-amber-700 rounded-full">
                  <User size={32} />
                </div>
                <h3 className="text-2xl font-bold mb-2">8,500+</h3>
                <p className="text-xl font-medium text-amber-700 mb-4">مستفيد</p>
                <p className="text-gray-600">
                  عدد الأشخاص الذين استفادوا من مبادرة SafeFood في مختلف أنحاء المغرب
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <div className="mb-4 inline-flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-700 rounded-full">
                  <TrendingUp size={32} />
                </div>
                <h3 className="text-2xl font-bold mb-2">38%</h3>
                <p className="text-xl font-medium text-blue-700 mb-4">انخفاض الهدر</p>
                <p className="text-gray-600">
                  نسبة انخفاض هدر الطعام لدى المطاعم والمتاجر المشاركة في المبادرة
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Statistics;